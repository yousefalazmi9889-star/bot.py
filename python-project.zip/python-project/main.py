"""Run the LEON Discord bot directly with ``python main.py``."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / "src"))

from python_project.main import main


if __name__ == "__main__":
    main()