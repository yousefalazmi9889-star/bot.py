# LEON Discord Bot

A Discord bot for LEON's livestream community. It provides the Kick livestream
link, social media links, and automatic replies to common Arabic questions
about the stream.

## Requirements

- Python 3.10 or newer
- A Discord bot application and token
- Message Content Intent enabled in the Discord Developer Portal
- Server Members Intent enabled if the bot's server requires it

## Configure the token

Store the bot token as a Replit Secret named `DISCORD_TOKEN`. Never put the
token directly in source code or commit it to the repository.

Ticket configuration is stored in SQLite per Discord Guild. Run
`/setup_ticket` in each server and optionally select that server's Category,
log channel, and support role. If no Category is selected, LEON creates one for
that Guild. No Category or log channel is shared globally between servers.

The claim, reminder, and close controls are authorized by the member's
`Manage Channels` permission, matching Discord's permission model.

## Install and run

From this directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --editable .
python main.py
```

You can also start it through the package entry point:

```bash
python-project
```

## 24/7 deployment

The project is configured for a Replit Reserved VM deployment, which is the
appropriate target for a continuously running Discord bot. The deployment
starts `run_production.sh`; this supervisor restarts LEON automatically after
an unexpected exit, using a short capped backoff to avoid a restart loop.

LEON also starts a Flask keep-alive endpoint on port `8080`. A `GET /` request
returns `LEON Bot is Online!`, which can be monitored by an uptime service.

Keep `DISCORD_TOKEN` and `GEMINI_API_KEY` in Replit Secrets. Do not place either
value in source code or deployment configuration.

## Commands

- `!live` — sends the Kick livestream link
- `!روابط`, `!مواقع`, `!social` — sends an Embed with the current official
  YouTube, Kick, and TikTok links
- `!مسح [العدد]` or `مسح [العدد]` — bulk-deletes recent messages; the default
  is 10 messages and the allowed range is 1–100
- `@LEON سؤال` — asks Gemini only when the member has the exact `AI` role;
  other members receive an Arabic permission message
- Arabic questions such as `متى البث` or `وين البث` — receive an automatic
  reply with the Kick link
- `/setup_ticket` — administrator-only command that saves this Guild's ticket
  Category/log settings and posts the persistent selector
- `/staff_stats @admin` — support-team statistics from SQLite
- `/staff_stats_all` — ranked statistics for every staff member
- `/clear amount` and `/purge amount` — slash-command message cleanup
- `/islamic_quiz` — 10-question interactive round from a 500-question bank
- `/guessing_game` — interactive guessing rounds from 120 items
- `/random_quiz` — interactive general-knowledge questions
- `!العاب` — قائمة الألعاب الجماعية
- `!اسئلة`, `!تخمين`, `!علم`, `!خريطة`, `!مافيا` — ألعاب جماعية تبدأ
  بلوحة انضمام لمدة 30 ثانية، بحد أقصى 20 لاعباً وCooldown مستقل لكل Guild

Tickets are stored in `leon_tickets.db`. Open tickets track the member's last
message only, so staff and bot messages do not reset the 24-hour inactivity
timer. Each side can use its reminder button only once per ticket; a reminder
whose DM is blocked is not counted. Closed tickets produce a transcript in the
configured log channel, and claimed tickets send a one-time persistent rating
view to the member.

Persistent ticket views support both the current `leon_ticket:*` component IDs
and the legacy IDs used by older panels, so existing buttons continue working
after bot restarts.

Ticket controls include claim, unclaim, one-time reminders, member access
management, transcript export, and reason-based closure. Ticket events and game
scores are persisted in the same SQLite database.

The security module protects channels, roles, links/invites, spam, mass
mentions, and webhook changes. It attributes structural changes through
Discord Audit Log, respects Administrator/owner exemptions and role hierarchy,
uses timeout/role removal for violations, and never bans.

The Gemini key is read from the `GEMINI_API_KEY` Replit Secret. The bot uses
the `gemini-2.5-flash` model and keeps prefixed commands separate from AI
mention handling.

## Project layout

```text
python-project/
├── main.py
├── pyproject.toml
├── src/
│   └── python_project/
│       ├── __init__.py
│       └── main.py
└── tests/
```