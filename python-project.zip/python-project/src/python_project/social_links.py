"""Canonical LEON social links shared by commands and security checks."""

from __future__ import annotations

KICK_URL = "https://kick.com/ileonsar906"
YOUTUBE_URL = "https://youtube.com/@ileonsar906?si=b6pSppr7AKRuWDNv"
TIKTOK_URL = "https://www.tiktok.com/@ileonsar906?_r=1&_t=ZS-99OdoynFkgO"

ALLOWED_SOCIAL_LINKS = frozenset(
    {
        KICK_URL,
        YOUTUBE_URL,
        TIKTOK_URL,
    }
)

ALLOWED_PREFIX_COMMANDS = frozenset({"!روابط", "!مواقع", "!social"})