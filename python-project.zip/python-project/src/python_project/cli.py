"""Command-line interface for the Python project."""

from __future__ import annotations

import argparse


def greeting(name: str) -> str:
    """Return a friendly greeting for a name."""
    clean_name = name.strip() or "world"
    return f"Hello, {clean_name}!"


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser."""
    parser = argparse.ArgumentParser(
        description="Print a friendly greeting.",
    )
    parser.add_argument(
        "name",
        nargs="?",
        default="world",
        help="The name to greet (default: world).",
    )
    return parser


def main() -> None:
    """Run the command-line application."""
    args = build_parser().parse_args()
    print(greeting(args.name))


if __name__ == "__main__":
    main()