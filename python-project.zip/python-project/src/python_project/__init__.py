"""A small, maintainable Python starter project."""

__version__ = "0.1.0"