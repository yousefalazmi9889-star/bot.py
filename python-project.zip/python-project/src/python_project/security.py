"""Guild-scoped anti-abuse protections for a discord.py bot.

Register this module with ``await register_security(bot, settings_provider=...)``.
The optional ticket predicate is called with a channel id and lets a ticket system
mark its own channels as safe before channel-create enforcement is considered.
"""

from __future__ import annotations

import asyncio
import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Awaitable, Callable

import discord
from discord.ext import commands

from .social_links import ALLOWED_PREFIX_COMMANDS, ALLOWED_SOCIAL_LINKS

CHANNEL_ROLE_TIMEOUT = timedelta(days=7)
LINK_TIMEOUT = timedelta(days=3)
MASS_MENTION_TIMEOUT = timedelta(days=1)
SPAM_WINDOW = timedelta(seconds=8)
SPAM_MESSAGE_LIMIT = 6
DESTRUCTIVE_WINDOW = timedelta(seconds=60)
DESTRUCTIVE_KICK_LIMIT = 5

# This intentionally catches links embedded in normal prose, including Discord
# invite aliases. It does not need an external URL parsing dependency.
LINK_PATTERN = re.compile(
    r"(?:https?://|www\.|discord(?:app)?\.com/invite/|discord\.gg/)\S+"
    r"|(?<![@\w])(?:[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?\.)+"
    r"[a-z]{2,63}(?::\d{2,5})?(?:/[^\s]*)?",
    re.IGNORECASE,
)


def utc_now() -> datetime:
    """Return an aware timestamp, factored out to make tests deterministic."""
    return datetime.now(timezone.utc)


def contains_prohibited_link(content: str) -> bool:
    """Whether text contains a non-whitelisted URL or Discord invite."""
    if content.strip() in ALLOWED_PREFIX_COMMANDS:
        return False
    sanitized = content
    for allowed_link in ALLOWED_SOCIAL_LINKS:
        sanitized = sanitized.replace(allowed_link, "")
    return bool(LINK_PATTERN.search(sanitized))


def contains_mass_mention(content: str, mention_everyone: bool = False) -> bool:
    """Detect @everyone/@here without relying only on Discord's message flag."""
    normalized = content.casefold()
    return mention_everyone or "@everyone" in normalized or "@here" in normalized


@dataclass
class GuildSecuritySettings:
    """Settings owned by one guild, rather than process-wide mutable settings."""

    log_channel_id: int
    ticket_channel_ids: set[int] = field(default_factory=set)
    punish_other_bots: bool = False


@dataclass
class GuildSecurityState:
    """In-memory, guild-local rate counters; suitable for isolated unit tests."""

    messages: dict[int, deque[datetime]] = field(
        default_factory=lambda: defaultdict(deque)
    )
    spam_strikes: dict[int, int] = field(default_factory=lambda: defaultdict(int))
    destructive_events: dict[tuple[int, str], deque[datetime]] = field(
        default_factory=lambda: defaultdict(deque)
    )

    @staticmethod
    def _trim(values: deque[datetime], since: datetime) -> None:
        while values and values[0] < since:
            values.popleft()

    def record_message(self, member_id: int, now: datetime) -> int:
        values = self.messages[member_id]
        self._trim(values, now - SPAM_WINDOW)
        values.append(now)
        return len(values)

    def record_destructive(self, member_id: int, kind: str, now: datetime) -> int:
        values = self.destructive_events[(member_id, kind)]
        self._trim(values, now - DESTRUCTIVE_WINDOW)
        values.append(now)
        return len(values)


TicketChannelCheck = Callable[[int], bool | Awaitable[bool]]
SecuritySettingsProvider = Callable[[int], GuildSecuritySettings | None]


class SecurityCog(commands.Cog):
    """Listeners which enforce the requested protection policy."""

    def __init__(
        self,
        bot: commands.Bot,
        *,
        settings_provider: SecuritySettingsProvider,
        ticket_channel_check: TicketChannelCheck | None = None,
    ) -> None:
        self.bot = bot
        self.settings_provider = settings_provider
        self.ticket_channel_check = ticket_channel_check
        self.state: dict[int, GuildSecurityState] = {}
        self.processed_audit_entries: set[tuple[int, int]] = set()

    def _settings(self, guild_id: int) -> GuildSecuritySettings | None:
        return self.settings_provider(guild_id)

    def _state(self, guild_id: int) -> GuildSecurityState:
        return self.state.setdefault(guild_id, GuildSecurityState())

    async def _is_ticket_channel(self, channel_id: int, guild_id: int) -> bool:
        settings = self._settings(guild_id)
        if settings is not None and channel_id in settings.ticket_channel_ids:
            return True
        if self.ticket_channel_check is None:
            return False
        result = self.ticket_channel_check(channel_id)
        return await result if hasattr(result, "__await__") else bool(result)

    async def _audit_entry(
        self, guild: discord.Guild, action: discord.AuditLogAction, target_id: int
    ) -> discord.AuditLogEntry | None:
        # Gateway events can arrive just before their audit entry.
        for attempt in range(3):
            try:
                async for entry in guild.audit_logs(limit=6, action=action):
                    target = entry.target
                    age = abs((utc_now() - entry.created_at).total_seconds())
                    if (
                        age <= 10
                        and target is not None
                        and getattr(target, "id", None) == target_id
                    ):
                        return entry
            except (discord.Forbidden, discord.HTTPException):
                return None
            if attempt < 2:
                await asyncio.sleep(0.5)
        return None

    def _is_exempt(
        self, member: discord.Member, settings: GuildSecuritySettings
    ) -> bool:
        if member.id == member.guild.owner_id:
            return True
        if self.bot.user is not None and member.id == self.bot.user.id:
            return True
        if member.guild_permissions.administrator:
            return True
        return member.bot and not settings.punish_other_bots

    async def _member_for_entry(
        self, guild: discord.Guild, entry: discord.AuditLogEntry
    ) -> discord.Member | None:
        executor = entry.user
        if executor is None:
            return None
        return guild.get_member(executor.id) or await guild.fetch_member(executor.id)

    async def _log(
        self,
        guild: discord.Guild,
        member: discord.abc.User | None,
        violation: str,
        action: str,
        punishment: str,
        target: str,
        success: bool,
        reason: str = "",
    ) -> None:
        settings = self._settings(guild.id)
        if settings is None:
            print(
                f"[SECURITY SETTINGS ERROR] Guild {guild.id} is not configured; "
                "security log was not sent.",
                flush=True,
            )
            return
        channel = guild.get_channel(settings.log_channel_id)
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            print(
                f"[SECURITY LOG ERROR] Channel {settings.log_channel_id} is "
                f"unavailable inside guild {guild.id}.",
                flush=True,
            )
            return
        actor = f"{member} ({member.id})" if member else "Unknown (unknown)"
        outcome = "نجحت" if success else "فشلت"
        embed = discord.Embed(
            title="🛡️ Security log",
            color=discord.Color.red() if success else discord.Color.orange(),
            timestamp=utc_now(),
        )
        embed.add_field(
            name="السيرفر",
            value=f"{guild.name}\nGuild ID: `{guild.id}`",
            inline=False,
        )
        embed.add_field(name="العضو", value=actor, inline=False)
        embed.add_field(name="نوع المخالفة", value=violation, inline=True)
        embed.add_field(name="الإجراء", value=action, inline=True)
        embed.add_field(name="العقوبة", value=punishment, inline=False)
        embed.add_field(name="المتأثر", value=target, inline=True)
        embed.add_field(name="النتيجة", value=outcome, inline=True)
        if reason:
            embed.add_field(
                name="سبب الفشل / ملاحظة",
                value=reason[:1024],
                inline=False,
            )
        try:
            await channel.send(
                embed=embed,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        except discord.HTTPException as exc:
            print(f"[SECURITY LOG ERROR] {exc}", flush=True)

    async def _punish(
        self, member: discord.Member, duration: timedelta, *, kick: bool = False
    ) -> tuple[bool, str]:
        """Remove only roles beneath the bot, then timeout or (rarely) kick."""
        me = member.guild.me
        if me is None:
            return False, "Bot member is unavailable"
        if member.top_role >= me.top_role:
            return False, "Member is above or equal to the bot in role hierarchy"
        failures: list[str] = []
        removable = [role for role in member.roles[1:] if not role.managed and role < me.top_role]
        if removable:
            try:
                await member.remove_roles(*removable, reason="LEON security enforcement")
            except (discord.Forbidden, discord.HTTPException) as exc:
                failures.append(f"role removal: {exc}")
        try:
            if kick:
                await member.kick(reason="Repeated destructive actions detected")
            else:
                await member.timeout(utc_now() + duration, reason="LEON security enforcement")
        except (discord.Forbidden, discord.HTTPException) as exc:
            failures.append(f"{'kick' if kick else 'timeout'}: {exc}")
        return not failures, "; ".join(failures)

    async def _handle_audit(
        self,
        guild: discord.Guild,
        target_id: int,
        audit_action: discord.AuditLogAction,
        violation: str,
        action: str,
        target: str,
        *,
        delete_target: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        settings = self._settings(guild.id)
        if settings is None:
            print(
                f"[SECURITY SETTINGS ERROR] Ignoring audit event from "
                f"unconfigured guild {guild.id}.",
                flush=True,
            )
            return
        entry = await self._audit_entry(guild, audit_action, target_id)
        if entry is None:
            await self._log(guild, None, violation, action, "None", target, False, "Audit entry unavailable")
            return
        audit_key = (guild.id, entry.id)
        if audit_key in self.processed_audit_entries:
            return
        self.processed_audit_entries.add(audit_key)
        try:
            member = await self._member_for_entry(guild, entry)
        except (discord.Forbidden, discord.HTTPException, discord.NotFound) as exc:
            await self._log(guild, entry.user, violation, action, "None", target, False, f"Cannot resolve executor: {exc}")
            return
        if member is None or self._is_exempt(member, settings):
            return
        if delete_target is not None:
            try:
                await delete_target()
            except (discord.Forbidden, discord.HTTPException) as exc:
                await self._log(guild, member, violation, action, "delete target + timeout", target, False, f"Could not delete target: {exc}")
        count = self._state(guild.id).record_destructive(member.id, violation, utc_now())
        kick = count >= DESTRUCTIVE_KICK_LIMIT
        success, reason = await self._punish(member, CHANNEL_ROLE_TIMEOUT, kick=kick)
        punishment = "Kick + manageable roles removed" if kick else "7 day timeout + manageable roles removed"
        await self._log(guild, member, violation, action, punishment, target, success, reason)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        if await self._is_ticket_channel(channel.id, channel.guild.id):
            return
        await self._handle_audit(channel.guild, channel.id, discord.AuditLogAction.channel_create, "Channel create", "created channel", channel.name, delete_target=lambda: channel.delete(reason="Unauthorized channel creation"))

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        await self._handle_audit(channel.guild, channel.id, discord.AuditLogAction.channel_delete, "Channel delete", "deleted channel", channel.name)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role) -> None:
        await self._handle_audit(role.guild, role.id, discord.AuditLogAction.role_create, "Role create", "created role", role.name, delete_target=lambda: role.delete(reason="Unauthorized role creation"))

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role) -> None:
        await self._handle_audit(role.guild, role.id, discord.AuditLogAction.role_delete, "Role delete", "deleted role", role.name)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.abc.GuildChannel) -> None:
        guild = channel.guild
        if self._settings(guild.id) is None:
            print(
                f"[SECURITY SETTINGS ERROR] Ignoring webhook event from "
                f"unconfigured guild {guild.id}.",
                flush=True,
            )
            return
        try:
            candidates: list[
                tuple[discord.AuditLogEntry, discord.AuditLogAction, str]
            ] = []
            for audit_action, label in (
                (discord.AuditLogAction.webhook_create, "created webhook"),
                (discord.AuditLogAction.webhook_update, "updated webhook"),
                (discord.AuditLogAction.webhook_delete, "deleted webhook"),
            ):
                async for entry in guild.audit_logs(limit=6, action=audit_action):
                    audit_channel = getattr(entry.extra, "channel", None)
                    age = abs((utc_now() - entry.created_at).total_seconds())
                    if (
                        age <= 10
                        and audit_channel is not None
                        and audit_channel.id == channel.id
                        and (guild.id, entry.id)
                        not in self.processed_audit_entries
                    ):
                        candidates.append((entry, audit_action, label))
            if not candidates:
                return
            entry, audit_action, label = max(
                candidates,
                key=lambda candidate: candidate[0].created_at,
            )
            target_id = getattr(entry.target, "id", None)
            if target_id is None:
                return

            delete_target: Callable[[], Awaitable[None]] | None = None
            if audit_action == discord.AuditLogAction.webhook_create:

                async def delete_created_webhook() -> None:
                    for webhook in await channel.webhooks():
                        if webhook.id == target_id:
                            await webhook.delete(
                                reason="Unauthorized webhook creation"
                            )
                            return

                delete_target = delete_created_webhook
            await self._handle_audit(
                guild,
                target_id,
                audit_action,
                "Webhook abuse",
                label,
                channel.name,
                delete_target=delete_target,
            )
        except (discord.Forbidden, discord.HTTPException):
            await self._log(guild, None, "Webhook abuse", "webhook changed", "None", channel.name, False, "Audit log unavailable")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or not isinstance(message.author, discord.Member):
            return
        settings = self._settings(message.guild.id)
        if settings is None:
            print(
                f"[SECURITY SETTINGS ERROR] Ignoring message event from "
                f"unconfigured guild {message.guild.id}.",
                flush=True,
            )
            return
        if self._is_exempt(message.author, settings):
            return
        violation: str | None = None
        duration: timedelta | None = None
        if contains_mass_mention(message.content, message.mention_everyone):
            violation, duration = "Mass mention", MASS_MENTION_TIMEOUT
        elif contains_prohibited_link(message.content):
            violation, duration = "Link/invite", LINK_TIMEOUT
        else:
            count = self._state(message.guild.id).record_message(message.author.id, utc_now())
            if count >= SPAM_MESSAGE_LIMIT:
                strike = self._state(message.guild.id).spam_strikes[message.author.id] + 1
                self._state(message.guild.id).spam_strikes[message.author.id] = strike
                duration = min(timedelta(days=3), timedelta(minutes=10 * (6 ** (strike - 1))))
                violation = "Spam"
        if violation is None or duration is None:
            return
        try:
            await message.delete()
            deleted = True
        except (discord.Forbidden, discord.HTTPException) as exc:
            deleted, delete_reason = False, str(exc)
        success, reason = await self._punish(message.author, duration)
        if not deleted:
            reason = f"{reason}; message delete: {delete_reason}".strip("; ")
        await self._log(message.guild, message.author, violation, "sent prohibited content", f"timeout {duration}", message.channel.mention, success and deleted, reason)


async def register_security(
    bot: commands.Bot,
    *,
    settings_provider: SecuritySettingsProvider,
    ticket_channel_check: TicketChannelCheck | None = None,
) -> SecurityCog:
    """Add and return the cog; call once during the bot's setup hook."""
    cog = SecurityCog(
        bot,
        settings_provider=settings_provider,
        ticket_channel_check=ticket_channel_check,
    )
    await bot.add_cog(cog)
    return cog