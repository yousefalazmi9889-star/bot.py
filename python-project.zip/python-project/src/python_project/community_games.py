"""Guild-isolated, prefix-command community games.

Load this extension with ``await bot.load_extension("python_project.community_games")``.
The state classes and question factories deliberately do not require Discord, so they
can also be exercised by unit tests.
"""

from __future__ import annotations

import asyncio
import random
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, Iterable
from urllib.parse import urlencode

import discord
from discord.ext import commands

from .admin_points import register_event_points

from .country_centers import COUNTRY_CENTERS

GAME_COOLDOWN = 5 * 60
JOIN_TIME = 30
MAX_PLAYERS = 20
QUESTION_TIME = 20
ROUNDS = 6
MAFIA_MIN_PLAYERS = 4
MAFIA_NIGHT_TIME = 30
MAFIA_DISCUSSION_TIME = 30
MAFIA_VOTE_TIME = 30

# ISO-3166 alpha-2 codes.  flagcdn and OpenStreetMap both use these public URLs.
_COUNTRY_DATA = """af|أفغانستان
al|ألبانيا
dz|الجزائر
ad|أندورا
ao|أنغولا
ag|أنتيغوا وبربودا
ar|الأرجنتين
am|أرمينيا
au|أستراليا
at|النمسا
az|أذربيجان
bs|الباهاما
bh|البحرين
bd|بنغلاديش
bb|باربادوس
by|بيلاروسيا
be|بلجيكا
bz|بليز
bj|بنين
bt|بوتان
bo|بوليفيا
ba|البوسنة والهرسك
bw|بوتسوانا
br|البرازيل
bn|بروناي
bg|بلغاريا
bf|بوركينا فاسو
bi|بوروندي
cv|الرأس الأخضر
kh|كمبوديا
cm|الكاميرون
ca|كندا
cf|جمهورية أفريقيا الوسطى
td|تشاد
cl|تشيلي
cn|الصين
co|كولومبيا
km|جزر القمر
cg|جمهورية الكونغو
cd|جمهورية الكونغو الديمقراطية
cr|كوستاريكا
ci|ساحل العاج
hr|كرواتيا
cu|كوبا
cy|قبرص
cz|التشيك
dk|الدنمارك
dj|جيبوتي
dm|دومينيكا
do|جمهورية الدومينيكان
ec|الإكوادور
eg|مصر
sv|السلفادور
gq|غينيا الاستوائية
er|إريتريا
ee|إستونيا
sz|إسواتيني
et|إثيوبيا
fj|فيجي
fi|فنلندا
fr|فرنسا
ga|الغابون
gm|غامبيا
ge|جورجيا
de|ألمانيا
gh|غانا
gr|اليونان
gd|غرينادا
gt|غواتيمالا
gn|غينيا
gw|غينيا بيساو
gy|غيانا
ht|هايتي
hn|هندوراس
hu|المجر
is|آيسلندا
in|الهند
id|إندونيسيا
ir|إيران
iq|العراق
ie|أيرلندا
il|إسرائيل
ps|فلسطين
it|إيطاليا
jm|جامايكا
jp|اليابان
jo|الأردن
kz|كازاخستان
ke|كينيا
ki|كيريباتي
kw|الكويت
kg|قيرغيزستان
la|لاوس
lv|لاتفيا
lb|لبنان
ls|ليسوتو
lr|ليبيريا
ly|ليبيا
li|ليختنشتاين
lt|ليتوانيا
lu|لوكسمبورغ
mg|مدغشقر
mw|مالاوي
my|ماليزيا
mv|المالديف
ml|مالي
mt|مالطا
mh|جزر مارشال
mr|موريتانيا
mu|موريشيوس
mx|المكسيك
fm|ميكرونيزيا
md|مولدوفا
mc|موناكو
mn|منغوليا
me|الجبل الأسود
ma|المغرب
mz|موزمبيق
mm|ميانمار
na|ناميبيا
nr|ناورو
np|نيبال
nl|هولندا
nz|نيوزيلندا
ni|نيكاراغوا
ne|النيجر
ng|نيجيريا
kp|كوريا الشمالية
mk|مقدونيا الشمالية
no|النرويج
om|عُمان
pk|باكستان
pw|بالاو
pa|بنما
pg|بابوا غينيا الجديدة
py|باراغواي
pe|بيرو
ph|الفلبين
pl|بولندا
pt|البرتغال
qa|قطر
ro|رومانيا
ru|روسيا
rw|رواندا
kn|سانت كيتس ونيفيس
lc|سانت لوسيا
vc|سانت فنسنت والغرينادين
ws|ساموا
sm|سان مارينو
st|ساو تومي وبرينسيبي
sa|السعودية
sn|السنغال
rs|صربيا
sc|سيشل
sl|سيراليون
sg|سنغافورة
sk|سلوفاكيا
si|سلوفينيا
sb|جزر سليمان
so|الصومال
za|جنوب أفريقيا
kr|كوريا الجنوبية
ss|جنوب السودان
es|إسبانيا
lk|سريلانكا
sd|السودان
sr|سورينام
se|السويد
ch|سويسرا
sy|سوريا
tj|طاجيكستان
tz|تنزانيا
th|تايلاند
tl|تيمور الشرقية
tg|توغو
to|تونغا
tt|ترينيداد وتوباغو
tn|تونس
tr|تركيا
tm|تركمانستان
tv|توفالو
ug|أوغندا
ua|أوكرانيا
ae|الإمارات
gb|المملكة المتحدة
us|الولايات المتحدة
uy|أوروغواي
uz|أوزبكستان
vu|فانواتو
va|الفاتيكان
ve|فنزويلا
vn|فيتنام
ye|اليمن
zm|زامبيا
zw|زيمبابوي"""
COUNTRIES = dict(line.split("|", 1) for line in _COUNTRY_DATA.splitlines())

GENERAL_QUESTIONS = [
    ("ما عاصمة أستراليا؟", ["سيدني", "كانبيرا", "ملبورن", "بيرث"], 1),
    ("أي كوكب هو الأكبر في مجموعتنا الشمسية؟", ["المريخ", "المشتري", "زحل", "الأرض"], 1),
    ("ما الغاز الذي تمتصه النباتات في البناء الضوئي؟", ["الأكسجين", "الهيليوم", "ثاني أكسيد الكربون", "النيتروجين"], 2),
    ("في أي قارة تقع البرازيل؟", ["أفريقيا", "أمريكا الجنوبية", "آسيا", "أوروبا"], 1),
    ("كم لاعباً في فريق كرة القدم داخل الملعب؟", ["9", "10", "11", "12"], 2),
    ("ما البحر الذي يفصل بين أفريقيا وأوروبا؟", ["البحر الأحمر", "البحر المتوسط", "بحر العرب", "بحر قزوين"], 1),
    ("ما وحدة قياس شدة التيار الكهربائي؟", ["الفولت", "الواط", "الأمبير", "الأوم"], 2),
    ("من رسم لوحة الموناليزا؟", ["فان غوخ", "ليوناردو دا فينشي", "بيكاسو", "رامبرانت"], 1),
    ("أي عضو يضخ الدم في جسم الإنسان؟", ["الرئة", "الكبد", "القلب", "الكلية"], 2),
    ("ما اللغة الرسمية في البرازيل؟", ["الإسبانية", "البرتغالية", "الإنجليزية", "الفرنسية"], 1),
]
GUESSING = {
    "حيوان سريع مشهور": ["الفهد", "الحصان", "الدب", "الفيل"],
    "آلة موسيقية لها مفاتيح": ["البيانو", "الطبل", "الناي", "العود"],
    "وسيلة نقل تسير على القضبان": ["القطار", "السفينة", "الطائرة", "الدراجة"],
    "فاكهة حمضية برتقالية اللون": ["البرتقال", "العنب", "الموز", "التفاح"],
    "مكان تُستعار منه الكتب": ["المكتبة", "المطار", "المستشفى", "الملعب"],
    "أداة لمعرفة الوقت": ["الساعة", "المطرقة", "المنشار", "الفرشاة"],
}


def normalize_answer(text: str) -> str:
    """Normalize Arabic spelling for comparisons in callers/tests."""
    replacements = str.maketrans("أإآةىؤئ", "اااهيوي")
    return " ".join(text.lower().strip().translate(replacements).split())


def is_game_admin(member: discord.Member) -> bool:
    permissions = member.guild_permissions
    return permissions.administrator or permissions.manage_guild or permissions.manage_messages


def flag_url(code: str) -> str:
    return f"https://flagcdn.com/w640/{code.lower()}.png"


def map_url(code: str) -> str:
    latitude, longitude = COUNTRY_CENTERS[code.lower()]
    query = urlencode(
        {
            "lang": "en_US",
            "ll": f"{longitude},{latitude}",
            "z": 4,
            "size": "600,400",
            "l": "map",
            "pt": f"{longitude},{latitude},pm2rdm",
        }
    )
    return f"https://static-maps.yandex.ru/1.x/?{query}"


def country_choices(code: str, rng: random.Random = random) -> list[str]:
    alternatives = [name for key, name in COUNTRIES.items() if key != code]
    choices = [COUNTRIES[code], *rng.sample(alternatives, 3)]
    rng.shuffle(choices)
    return choices


def assign_mafia_roles(
    player_ids: Iterable[int],
    rng: random.Random = random,
) -> dict[int, str]:
    """Assign the classic Mafia roles without sharing state between guilds."""
    shuffled = list(player_ids)
    rng.shuffle(shuffled)
    if len(shuffled) < MAFIA_MIN_PLAYERS:
        raise ValueError("Mafia requires at least four players")
    mafia_count = max(1, len(shuffled) // 4)
    roles: dict[int, str] = {}
    for player_id in shuffled[:mafia_count]:
        roles[player_id] = "mafia"
    roles[shuffled[mafia_count]] = "doctor"
    roles[shuffled[mafia_count + 1]] = "detective"
    for player_id in shuffled[mafia_count + 2 :]:
        roles[player_id] = "civilian"
    return roles


def mafia_winner(alive: set[int], roles: dict[int, str]) -> str | None:
    """Return the winning side when a standard Mafia win condition is met."""
    mafia_alive = sum(roles[player_id] == "mafia" for player_id in alive)
    civilians_alive = len(alive) - mafia_alive
    if mafia_alive == 0:
        return "civilians"
    if mafia_alive >= civilians_alive:
        return "mafia"
    return None


@dataclass
class GuildGameState:
    game_type: str
    players: set[int] = field(default_factory=set)
    max_players: int = MAX_PLAYERS


class GameRegistry:
    """Small pure per-guild state store; injectable clock makes cooldown testable."""

    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self.active: dict[int, GuildGameState] = {}
        self.cooldowns: dict[int, float] = {}
        self.clock = clock

    def cooldown_remaining(self, guild_id: int) -> float:
        remaining = self.cooldowns.get(guild_id, 0) - self.clock()
        if remaining <= 0:
            self.cooldowns.pop(guild_id, None)
            return 0
        return remaining

    def start(self, guild_id: int, game_type: str) -> bool:
        if guild_id in self.active or self.cooldown_remaining(guild_id):
            return False
        self.active[guild_id] = GuildGameState(game_type)
        self.cooldowns[guild_id] = self.clock() + GAME_COOLDOWN
        return True

    def finish(self, guild_id: int) -> None:
        self.active.pop(guild_id, None)

    def toggle_player(self, guild_id: int, user_id: int) -> bool | None:
        result = self.registration_action(guild_id, user_id)
        if result == "joined":
            return True
        if result == "left":
            return False
        return None

    def registration_action(self, guild_id: int, user_id: int) -> str:
        state = self.active.get(guild_id)
        if state is None:
            return "closed"
        if user_id in state.players:
            state.players.remove(user_id)
            return "left"
        if len(state.players) >= state.max_players:
            return "full"
        state.players.add(user_id)
        return "joined"


def format_time(seconds: float) -> str:
    minutes, seconds = divmod(max(0, int(seconds)), 60)
    return f"{minutes} دقيقة و {seconds} ثانية" if minutes else f"{seconds} ثانية"


class JoinView(discord.ui.View):
    def __init__(
        self,
        registry: GameRegistry,
        guild_id: int,
        game_type: str,
    ) -> None:
        super().__init__(timeout=JOIN_TIME)
        self.registry = registry
        self.guild_id = guild_id
        self.game_type = game_type
        self.message: discord.Message | None = None

    def content(self, *, closed: bool = False) -> str:
        state = self.registry.active.get(self.guild_id)
        players = sorted(state.players) if state is not None else []
        player_list = (
            "\n".join(f"• <@{player_id}>" for player_id in players)
            if players
            else "لا يوجد لاعبون حتى الآن."
        )
        status = (
            "🔒 انتهى التسجيل."
            if closed
            else "اضغط الزر للتسجيل أو إلغاء التسجيل. "
            "يبدأ اللعب بعد **30 ثانية**."
        )
        return (
            f"🎮 **{self.game_type}**\n{status}\n"
            f"المشاركون: **{len(players)}/{MAX_PLAYERS}**\n{player_list}"
        )

    @discord.ui.button(label="انضمام / إلغاء", emoji="🎮", style=discord.ButtonStyle.success)
    async def join(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        if interaction.guild_id != self.guild_id or interaction.user.bot:
            await interaction.response.send_message("لا يمكن التسجيل هنا.", ephemeral=True)
            return
        result = self.registry.registration_action(
            self.guild_id,
            interaction.user.id,
        )
        if result == "closed":
            await interaction.response.send_message("انتهى التسجيل.", ephemeral=True)
            return
        if result == "full":
            await interaction.response.send_message(
                "⛔ اكتمل عدد اللاعبين.",
                ephemeral=True,
            )
            return
        text = (
            f"🟢 دخل اللاعب: {interaction.user.mention}"
            if result == "joined"
            else f"🔴 خرج اللاعب: {interaction.user.mention}"
        )
        await interaction.response.send_message(
            text,
            allowed_mentions=discord.AllowedMentions(users=True),
        )
        if self.message is not None:
            try:
                await self.message.edit(content=self.content(), view=self)
            except discord.HTTPException:
                pass

    async def on_timeout(self) -> None:
        for child in self.children:
            child.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(
                    content=self.content(closed=True),
                    view=self,
                )
            except discord.HTTPException:
                pass


class ChoiceButton(discord.ui.Button["RoundView"]):
    def __init__(self, label: str, index: int) -> None:
        super().__init__(label=label[:80], style=discord.ButtonStyle.primary)
        self.index = index

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view:
            await self.view.choose(interaction, self.index)


class RoundView(discord.ui.View):
    def __init__(self, player_ids: Iterable[int], choices: list[str], correct_index: int) -> None:
        super().__init__(timeout=QUESTION_TIME)
        self.player_ids, self.correct_index = set(player_ids), correct_index
        self.answered: set[int] = set()
        self.winner: discord.abc.User | None = None
        self.message: discord.Message | None = None
        for index, choice in enumerate(choices):
            self.add_item(ChoiceButton(choice, index))

    async def choose(self, interaction: discord.Interaction, index: int) -> None:
        if interaction.user.id not in self.player_ids:
            await interaction.response.send_message("❌ أنت لست من المسجلين.", ephemeral=True)
            return
        if interaction.user.id in self.answered:
            await interaction.response.send_message("❌ يمكنك الإجابة مرة واحدة فقط.", ephemeral=True)
            return
        if self.winner is not None:
            await interaction.response.send_message("❌ انتهت هذه الجولة.", ephemeral=True)
            return
        self.answered.add(interaction.user.id)
        answer_message = f"✅ أجاب اللاعب: {interaction.user.mention}"
        if index != self.correct_index:
            await interaction.response.send_message(
                f"{answer_message}\n❌ إجابة خاطئة.",
                allowed_mentions=discord.AllowedMentions(users=True),
            )
            return
        self.winner = interaction.user
        for child in self.children:
            child.disabled = True
        await interaction.response.send_message(
            answer_message,
            allowed_mentions=discord.AllowedMentions(users=True),
        )
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass
        self.stop()

    async def on_timeout(self) -> None:
        for child in self.children:
            child.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


class PlayerTargetButton(discord.ui.Button["PlayerTargetView"]):
    def __init__(self, player_id: int, label: str) -> None:
        super().__init__(
            label=label[:80],
            style=discord.ButtonStyle.secondary,
        )
        self.player_id = player_id

    async def callback(self, interaction: discord.Interaction) -> None:
        if self.view is not None:
            await self.view.choose(interaction, self.player_id)


class PlayerTargetView(discord.ui.View):
    """Private single-choice view for one Mafia night action."""

    def __init__(
        self,
        actor_id: int,
        targets: dict[int, str],
    ) -> None:
        super().__init__(timeout=MAFIA_NIGHT_TIME)
        self.actor_id = actor_id
        self.choice: int | None = None
        for player_id, label in targets.items():
            self.add_item(PlayerTargetButton(player_id, label))

    async def choose(
        self,
        interaction: discord.Interaction,
        player_id: int,
    ) -> None:
        if interaction.user.id != self.actor_id:
            await interaction.response.send_message(
                "هذا الاختيار ليس لك.",
            )
            return
        if self.choice is not None:
            await interaction.response.send_message(
                "تم تسجيل اختيارك مسبقاً.",
            )
            return
        self.choice = player_id
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(
            content="✅ تم تسجيل اختيارك سراً.",
            view=self,
        )
        self.stop()


class MafiaVoteView(discord.ui.View):
    """Guild-channel daytime vote with one vote per living participant."""

    def __init__(
        self,
        voter_ids: set[int],
        targets: dict[int, str],
    ) -> None:
        super().__init__(timeout=MAFIA_VOTE_TIME)
        self.voter_ids = set(voter_ids)
        self.votes: dict[int, int] = {}
        self.message: discord.Message | None = None
        for player_id, label in targets.items():
            self.add_item(PlayerTargetButton(player_id, label))

    async def choose(
        self,
        interaction: discord.Interaction,
        player_id: int,
    ) -> None:
        if interaction.user.id not in self.voter_ids:
            await interaction.response.send_message(
                "❌ أنت لست لاعباً حياً في هذه الجولة.",
                ephemeral=True,
            )
            return
        if interaction.user.id in self.votes:
            await interaction.response.send_message(
                "❌ يمكنك التصويت مرة واحدة فقط.",
                ephemeral=True,
            )
            return
        self.votes[interaction.user.id] = player_id
        await interaction.response.send_message(
            "✅ تم تسجيل صوتك.",
            ephemeral=True,
        )
        if len(self.votes) == len(self.voter_ids):
            self.stop()

    async def on_timeout(self) -> None:
        for child in self.children:
            child.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


class CommunityGames(commands.Cog):
    def __init__(self, bot: commands.Bot, registry: GameRegistry | None = None) -> None:
        self.bot, self.registry = bot, registry or GameRegistry()

    async def _begin(self, ctx: commands.Context, game_type: str) -> set[int] | None:
        if ctx.guild is None or not isinstance(ctx.author, discord.Member) or not is_game_admin(ctx.author):
            await ctx.send("❌ هذا الأمر متاح للإدارة فقط داخل السيرفر.")
            return None
        guild_id = ctx.guild.id
        if guild_id in self.registry.active:
            await ctx.send("🎮 توجد لعبة شغالة حالياً في هذا السيرفر.")
            return None
        remaining = self.registry.cooldown_remaining(guild_id)
        if remaining:
            await ctx.send(f"⏳ انتظر {format_time(remaining)} قبل بدء لعبة جديدة.")
            return None
        self.registry.start(guild_id, game_type)
        view = JoinView(self.registry, guild_id, game_type)
        try:
            view.message = await ctx.send(
                view.content(),
                view=view,
            )
            await view.wait()
            return set(self.registry.active[guild_id].players)
        except Exception:
            self.registry.finish(guild_id)
            raise

    async def _play(self, ctx: commands.Context, game_type: str, rounds: list[tuple[str, list[str], int, str | None]]) -> None:
        players = await self._begin(ctx, game_type)
        if players is None:
            return
        try:
            if not players:
                await ctx.send("❌ لم ينضم أي لاعب، تم إلغاء اللعبة.")
                return
            scores = {player: 0 for player in players}
            for number, (question, choices, correct_index, image) in enumerate(rounds, 1):
                view = RoundView(players, choices, correct_index)
                embed = discord.Embed(
                    title=game_type,
                    description=f"**الجولة {number}/{len(rounds)}**\n{question}\n\n⏱️ 20 ثانية",
                    color=discord.Color.blurple(),
                )
                if image:
                    embed.set_image(url=image)
                message = await ctx.send(embed=embed, view=view)
                view.message = message
                await view.wait()
                if view.winner:
                    scores[view.winner.id] += 1
                    result = f"✅ {view.winner.mention} أجاب بشكل صحيح!"
                else:
                    result = "⌛ انتهى الوقت دون إجابة صحيحة."
                try:
                    await message.edit(content=f"{result}\nالإجابة: **{choices[correct_index]}**", view=None)
                except discord.HTTPException:
                    pass
                await asyncio.sleep(1)
            ranking = sorted(scores.items(), key=lambda item: item[1], reverse=True)
            lines = [f"**{place}.** <@{user_id}> — `{score}` نقطة" for place, (user_id, score) in enumerate(ranking, 1)]
            await ctx.send(embed=discord.Embed(title="🏆 النتائج", description="\n".join(lines), color=discord.Color.gold()))
            if isinstance(ctx.author, discord.Member):
                await register_event_points(
                    ctx.author,
                    ctx.message.id,
                    len(players),
                    MAX_PLAYERS,
                )
        finally:
            self.registry.finish(ctx.guild.id)

    @staticmethod
    def _player_labels(
        guild: discord.Guild,
        player_ids: Iterable[int],
    ) -> dict[int, str]:
        labels: dict[int, str] = {}
        for player_id in player_ids:
            member = guild.get_member(player_id)
            labels[player_id] = (
                member.display_name if member is not None else str(player_id)
            )
        return labels

    async def _night_choice(
        self,
        member: discord.Member,
        prompt: str,
        targets: dict[int, str],
    ) -> int | None:
        if not targets:
            return None
        view = PlayerTargetView(member.id, targets)
        try:
            message = await member.send(prompt, view=view)
        except (discord.Forbidden, discord.HTTPException):
            return None
        await view.wait()
        try:
            await message.edit(view=None)
        except discord.HTTPException:
            pass
        return view.choice

    async def _play_mafia(self, ctx: commands.Context) -> None:
        players = await self._begin(ctx, "🕵️ لعبة مافيا")
        if players is None:
            return
        if ctx.guild is None:
            return
        guild_id = ctx.guild.id
        try:
            if len(players) < MAFIA_MIN_PLAYERS:
                await ctx.send(
                    "❌ تحتاج لعبة مافيا إلى 4 لاعبين على الأقل."
                )
                return

            members = {
                player_id: ctx.guild.get_member(player_id)
                for player_id in players
            }
            if any(member is None for member in members.values()):
                await ctx.send(
                    "❌ تعذر العثور على أحد اللاعبين؛ ألغيت اللعبة بأمان."
                )
                return

            roles = assign_mafia_roles(players)
            role_messages = {
                "mafia": (
                    "🔪 دورك: **Mafia**\n"
                    "في الليل اختر لاعباً لإخراجه دون كشف دورك."
                ),
                "doctor": (
                    "🩺 دورك: **Doctor**\n"
                    "في الليل اختر لاعباً لحمايته، ويمكنك حماية نفسك."
                ),
                "detective": (
                    "🔎 دورك: **Detective**\n"
                    "في الليل افحص لاعباً لمعرفة هل هو من المافيا."
                ),
                "civilian": (
                    "🏘️ دورك: **Civilian**\n"
                    "ناقش في النهار وصوّت لاكتشاف المافيا."
                ),
            }
            dm_failed = False
            for player_id, role in roles.items():
                member = members[player_id]
                if member is None:
                    dm_failed = True
                    continue
                try:
                    await member.send(
                        "🎭 **بدأت لعبة مافيا**\n"
                        f"{role_messages[role]}\n"
                        "⚠️ لا تكشف هذه الرسالة أو دورك في القناة."
                    )
                except (discord.Forbidden, discord.HTTPException):
                    dm_failed = True
            if dm_failed:
                await ctx.send(
                    "❌ تعذر إرسال الأدوار بشكل خاص لأحد اللاعبين، "
                    "لذلك ألغيت اللعبة دون كشف أي دور."
                )
                return

            await ctx.send(
                "🎭 **قواعد مافيا**\n"
                "• الأدوار سرية ولا تُكشف في القناة.\n"
                "• ليلاً تختار المافيا هدفاً، ويحمي الطبيب لاعباً، "
                "ويفحص المحقق لاعباً.\n"
                "• نهاراً يناقش الأحياء ثم يصوّت كل لاعب مرة واحدة.\n"
                "• يفوز المدنيون بإخراج كل المافيا، وتفوز المافيا "
                "عندما يصبح عددها مساوياً لبقية الأحياء."
            )

            alive = set(players)
            day_number = 1
            while mafia_winner(alive, roles) is None:
                labels = self._player_labels(ctx.guild, alive)
                mafia_ids = [
                    player_id
                    for player_id in alive
                    if roles[player_id] == "mafia"
                ]
                doctor_id = next(
                    (
                        player_id
                        for player_id in alive
                        if roles[player_id] == "doctor"
                    ),
                    None,
                )
                detective_id = next(
                    (
                        player_id
                        for player_id in alive
                        if roles[player_id] == "detective"
                    ),
                    None,
                )
                mafia_targets = {
                    player_id: labels[player_id]
                    for player_id in alive
                    if roles[player_id] != "mafia"
                }
                all_targets = {
                    player_id: labels[player_id]
                    for player_id in alive
                }

                await ctx.send(
                    f"🌙 **الليلة {day_number}**\n"
                    "أُرسلت قدرات الليل في الخاص. أمامكم 30 ثانية."
                )
                mafia_tasks = [
                    self._night_choice(
                        members[player_id],
                        "🌙 اختر هدف المافيا لهذه الليلة:",
                        mafia_targets,
                    )
                    for player_id in mafia_ids
                    if members[player_id] is not None
                ]
                doctor_task = (
                    self._night_choice(
                        members[doctor_id],
                        "🌙 اختر لاعباً لحمايته هذه الليلة:",
                        all_targets,
                    )
                    if doctor_id is not None
                    and members[doctor_id] is not None
                    else asyncio.sleep(0, result=None)
                )
                detective_targets = (
                    {
                        player_id: labels[player_id]
                        for player_id in alive
                        if player_id != detective_id
                    }
                    if detective_id is not None
                    else {}
                )
                detective_task = (
                    self._night_choice(
                        members[detective_id],
                        "🌙 اختر لاعباً لفحصه هذه الليلة:",
                        detective_targets,
                    )
                    if detective_id is not None
                    and members[detective_id] is not None
                    else asyncio.sleep(0, result=None)
                )
                night_results = await asyncio.gather(
                    *mafia_tasks,
                    doctor_task,
                    detective_task,
                )
                mafia_choices = [
                    choice
                    for choice in night_results[: len(mafia_tasks)]
                    if choice in mafia_targets
                ]
                protected_id = night_results[-2]
                investigated_id = night_results[-1]

                if mafia_choices:
                    counts = Counter(mafia_choices)
                    highest = max(counts.values())
                    tied = [
                        player_id
                        for player_id, votes in counts.items()
                        if votes == highest
                    ]
                    mafia_target = random.choice(tied)
                else:
                    mafia_target = random.choice(list(mafia_targets))

                if (
                    detective_id is not None
                    and investigated_id in roles
                    and members[detective_id] is not None
                ):
                    result = (
                        "من المافيا"
                        if roles[investigated_id] == "mafia"
                        else "ليس من المافيا"
                    )
                    try:
                        await members[detective_id].send(
                            f"🔎 نتيجة التحقيق: **{result}**."
                        )
                    except (discord.Forbidden, discord.HTTPException):
                        pass

                if mafia_target == protected_id:
                    await ctx.send(
                        "🌅 انتهى الليل بسلام؛ نجح الطبيب في الحماية."
                    )
                else:
                    alive.discard(mafia_target)
                    await ctx.send(
                        f"🌅 تم إخراج <@{mafia_target}> أثناء الليل.\n"
                        "لن يُكشف دوره في القناة.",
                        allowed_mentions=discord.AllowedMentions(users=True),
                    )

                winner = mafia_winner(alive, roles)
                if winner is not None:
                    break

                await ctx.send(
                    f"☀️ **اليوم {day_number}**\n"
                    "لديكم 30 ثانية للنقاش قبل بدء التصويت."
                )
                await asyncio.sleep(MAFIA_DISCUSSION_TIME)

                labels = self._player_labels(ctx.guild, alive)
                vote_view = MafiaVoteView(alive, labels)
                vote_view.message = await ctx.send(
                    "🗳️ صوّت لإخراج لاعب. لكل لاعب حي صوت واحد.",
                    view=vote_view,
                )
                await vote_view.wait()
                for child in vote_view.children:
                    child.disabled = True
                try:
                    await vote_view.message.edit(view=vote_view)
                except discord.HTTPException:
                    pass
                if vote_view.votes:
                    counts = Counter(vote_view.votes.values())
                    highest = max(counts.values())
                    tied = [
                        player_id
                        for player_id, votes in counts.items()
                        if votes == highest
                    ]
                    eliminated = random.choice(tied)
                    alive.discard(eliminated)
                    await ctx.send(
                        f"🚪 صوّت اللاعبون لإخراج <@{eliminated}>.\n"
                        "لن يُكشف دوره في القناة.",
                        allowed_mentions=discord.AllowedMentions(users=True),
                    )
                else:
                    await ctx.send("⌛ لم يُسجل أي تصويت هذا اليوم.")
                day_number += 1

            winner = mafia_winner(alive, roles)
            if winner == "mafia":
                await ctx.send("🔪 انتهت اللعبة: **فازت المافيا**.")
            else:
                await ctx.send("🏘️ انتهت اللعبة: **فاز المدنيون**.")
            if isinstance(ctx.author, discord.Member):
                await register_event_points(
                    ctx.author,
                    ctx.message.id,
                    len(players),
                    MAX_PLAYERS,
                )
        finally:
            self.registry.finish(guild_id)

    @commands.command(name="العاب")
    async def games(self, ctx: commands.Context) -> None:
        if ctx.guild is None or not isinstance(ctx.author, discord.Member) or not is_game_admin(ctx.author):
            await ctx.send("❌ هذا الأمر متاح للإدارة فقط داخل السيرفر.")
            return
        await ctx.send(
            "🎮 `!اسئلة` أسئلة عامة • `!تخمين` تخمين • "
            "`!علم` أعلام • `!خريطة` خرائط • `!مافيا` مافيا"
        )

    @commands.command(name="اسئلة")
    async def questions(self, ctx: commands.Context) -> None:
        selected = random.sample(GENERAL_QUESTIONS, min(ROUNDS, len(GENERAL_QUESTIONS)))
        await self._play(ctx, "🧠 الأسئلة العامة", [(q, a, c, None) for q, a, c in selected])

    @commands.command(name="تخمين")
    async def guessing(self, ctx: commands.Context) -> None:
        selected = random.sample(list(GUESSING.items()), min(ROUNDS, len(GUESSING)))
        await self._play(ctx, "🎯 لعبة التخمين", [(f"خمن الشيء: **{hint}**", options, 0, None) for hint, options in selected])

    async def _country_game(
        self,
        ctx: commands.Context,
        title: str,
        image_factory: Callable[[str], str],
        question: str = "ما اسم هذه الدولة؟",
    ) -> None:
        codes = random.sample(list(COUNTRIES), min(ROUNDS, len(COUNTRIES)))
        rounds = []
        for code in codes:
            choices = country_choices(code)
            rounds.append(
                (
                    question,
                    choices,
                    choices.index(COUNTRIES[code]),
                    image_factory(code),
                )
            )
        await self._play(ctx, title, rounds)

    @commands.command(name="علم")
    async def flag(self, ctx: commands.Context) -> None:
        await self._country_game(ctx, "🏳️ خمن الدولة من العلم", flag_url)

    @commands.command(name="خريطة")
    async def map(self, ctx: commands.Context) -> None:
        await self._country_game(
            ctx,
            "🗺️ خمن الدولة من الخريطة",
            map_url,
            "🌍 أين تقع هذه الدولة؟",
        )

    @commands.command(name="مافيا")
    async def mafia(self, ctx: commands.Context) -> None:
        await self._play_mafia(ctx)


async def setup(bot: commands.Bot) -> None:
    """discord.py extension entry point."""
    await bot.add_cog(CommunityGames(bot))