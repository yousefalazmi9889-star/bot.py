"""Allow the package to run with ``python -m python_project``."""

from .cli import main


if __name__ == "__main__":
    main()