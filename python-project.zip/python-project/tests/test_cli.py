import random
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from pathlib import Path
from tempfile import TemporaryDirectory

from python_project.games import (
    GUESS_CATEGORIES,
    GameDatabase,
    guessing_questions,
)
from python_project.community_games import (
    COUNTRIES,
    GAME_COOLDOWN,
    MAX_PLAYERS,
    GameRegistry,
    assign_mafia_roles,
    country_choices,
    flag_url,
    mafia_winner,
    map_url,
)
from python_project.country_centers import COUNTRY_CENTERS
from python_project.admin_points import (
    AdminPointsCog,
    AdminPointsDatabase,
    BT_DAILY_POINTS_CHANNEL_ID,
    BT_GUILD_ID,
    BT_ROLE_IDS,
    LN_DAILY_POINTS_CHANNEL_ID,
    LN_GUILD_ID,
    LN_ROLE_IDS,
    POINT_RANKS,
    REPORT_CUSTOM_ID,
    rank_from_points,
    supported_guild_ids,
)
from python_project.security import (
    GuildSecurityState,
    contains_mass_mention,
    contains_prohibited_link,
)
from python_project.social_links import (
    KICK_URL,
    TIKTOK_URL,
    YOUTUBE_URL,
)
from python_project.main import (
    AdminApplicationModal,
    CATALOG_GUILD_ID,
    CATALOG_LOG_CHANNEL_ID,
    DEFAULT_CLEAR_AMOUNT,
    DATABASE_FILE,
    GEMINI_MODEL,
    KEEP_ALIVE_PORT,
    LEGACY_COMPONENT_IDS,
    LEGACY_SELECT_ID,
    MAX_CLEAR_AMOUNT,
    RatingView,
    PartnershipModal,
    SUBMISSION_TYPES,
    SubmissionDecisionView,
    SupportSelect,
    TICKET_TYPES,
    TicketControlView,
    TicketDatabase,
    TicketLauncher,
    bot,
    is_stream_question,
    keep_alive_home,
    member_has_ai_role,
    main,
    parse_clear_amount,
    parse_discord_user_id,
    web_app,
)


class BotConfigurationTests(unittest.TestCase):
    @patch.dict(
        "os.environ",
        {
            "TICKET_CATEGORY_ID": "1",
            "TICKET_LOG_CHANNEL_ID": "2",
            "SUPPORT_ROLE_ID": "0",
        },
        clear=True,
    )
    def test_main_requires_a_token(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "DISCORD_TOKEN"):
            main()

    def test_commands_are_case_insensitive(self) -> None:
        self.assertTrue(bot.case_insensitive)

    def test_livestream_questions_are_recognized(self) -> None:
        self.assertTrue(is_stream_question("متى البث"))
        self.assertTrue(is_stream_question("وين البث"))
        self.assertTrue(is_stream_question("  متى   البث  "))

    def test_unrelated_messages_are_not_recognized(self) -> None:
        self.assertFalse(is_stream_question("مرحبا بالجميع"))

    def test_clear_command_defaults_to_ten_messages(self) -> None:
        self.assertEqual(parse_clear_amount("مسح"), DEFAULT_CLEAR_AMOUNT)
        self.assertEqual(parse_clear_amount("مسح   "), DEFAULT_CLEAR_AMOUNT)

    def test_clear_command_accepts_one_to_one_hundred_messages(self) -> None:
        self.assertEqual(parse_clear_amount("مسح 1"), 1)
        self.assertEqual(parse_clear_amount(f"مسح {MAX_CLEAR_AMOUNT}"), MAX_CLEAR_AMOUNT)

    def test_clear_command_rejects_invalid_amounts(self) -> None:
        self.assertIsNone(parse_clear_amount("مسح 0"))
        self.assertIsNone(parse_clear_amount("مسح 101"))
        self.assertIsNone(parse_clear_amount("مسح عشرة"))
        self.assertIsNone(parse_clear_amount("مسح 10 رسائل"))

    def test_only_the_exact_ai_role_is_allowed(self) -> None:
        self.assertTrue(
            member_has_ai_role(SimpleNamespace(roles=[SimpleNamespace(name="AI")]))
        )
        self.assertFalse(
            member_has_ai_role(SimpleNamespace(roles=[SimpleNamespace(name="ai")]))
        )
        self.assertFalse(member_has_ai_role(SimpleNamespace(roles=[])))

    def test_gemini_model_is_configured(self) -> None:
        self.assertEqual(GEMINI_MODEL, "gemini-2.5-flash")

    def test_keep_alive_endpoint_is_configured(self) -> None:
        self.assertEqual(KEEP_ALIVE_PORT, 8080)
        self.assertEqual(keep_alive_home(), "LEON Bot is Online!")
        response = web_app.test_client().get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_data(as_text=True), "LEON Bot is Online!")

    def test_slash_commands_include_management_and_games(self) -> None:
        names = {command.name for command in bot.tree.get_commands()}
        self.assertTrue(
            {
                "setup_ticket",
                "staff_stats",
                "staff_stats_all",
                "clear",
                "purge",
                "islamic_quiz",
                "guessing_game",
                "random_quiz",
            }.issubset(names)
        )
        admin_names = {
            command.name for command in AdminPointsCog.__cog_app_commands__
        }
        self.assertEqual(admin_names, {"adminstats", "admininfo"})

    def test_admin_point_ranks_match_required_thresholds(self) -> None:
        self.assertEqual(
            POINT_RANKS,
            [
                ("Junior", 0),
                ("High Junior", 200),
                ("Admin", 500),
                ("Super Admin", 900),
                ("High Admin", 1400),
                ("Admin Staff", 2000),
            ],
        )
        self.assertEqual(rank_from_points(0), "Junior")
        self.assertEqual(rank_from_points(899), "Admin")
        self.assertEqual(rank_from_points(2000), "Admin Staff")
        self.assertEqual(REPORT_CUSTOM_ID, "leon_admin_points:confirm")

    def test_bt_and_ln_admin_points_ids_are_fully_configured(self) -> None:
        self.assertTrue(BT_GUILD_ID)
        self.assertTrue(LN_GUILD_ID)
        self.assertNotEqual(BT_GUILD_ID, LN_GUILD_ID)
        self.assertTrue(BT_DAILY_POINTS_CHANNEL_ID)
        self.assertTrue(LN_DAILY_POINTS_CHANNEL_ID)
        self.assertEqual(set(BT_ROLE_IDS), {name for name, _ in POINT_RANKS} | {
            "High Staff",
            "Colonel",
            "High Colonel",
            "Co Manager",
            "Manager Staff",
            "Leader",
            "Co Founder",
            "Founder",
        })
        self.assertEqual(set(BT_ROLE_IDS), set(LN_ROLE_IDS))
        self.assertTrue(all(BT_ROLE_IDS.values()))
        self.assertTrue(all(LN_ROLE_IDS.values()))
        all_ids = [
            BT_GUILD_ID,
            LN_GUILD_ID,
            BT_DAILY_POINTS_CHANNEL_ID,
            LN_DAILY_POINTS_CHANNEL_ID,
            *BT_ROLE_IDS.values(),
            *LN_ROLE_IDS.values(),
        ]
        self.assertEqual(len(all_ids), len(set(all_ids)))
        self.assertEqual(
            supported_guild_ids(),
            (BT_GUILD_ID, LN_GUILD_ID),
        )

    def test_admin_counter_is_atomic_deduplicated_and_capped(self) -> None:
        with TemporaryDirectory() as directory:
            points = AdminPointsDatabase(Path(directory) / "points.db")
            points.initialize()
            for message_id in range(100):
                self.assertTrue(
                    points.count_activity(
                        1, 2, "2026-09-03", "messages", f"message:{message_id}"
                    )
                )
            self.assertFalse(
                points.count_activity(
                    1, 2, "2026-09-03", "messages", "message:99"
                )
            )
            row = points.daily_rows(1, "2026-09-03")[0]
            self.assertEqual(row["message_points"], 1)
            self.assertEqual(row["total_points"], 1)

    def test_daily_report_can_only_be_approved_once(self) -> None:
        with TemporaryDirectory() as directory:
            points = AdminPointsDatabase(Path(directory) / "points.db")
            points.initialize()
            self.assertTrue(
                points.add_points(
                    1, 2, "2026-09-02", 3, "events", "game:1"
                )
            )
            points.reserve_report(1, "2026-09-02")
            success, _, users = points.approve_day(1, "2026-09-02", 10)
            self.assertTrue(success)
            self.assertEqual(users, [2])
            success, _, users = points.approve_day(1, "2026-09-02", 11)
            self.assertFalse(success)
            self.assertEqual(users, [])
            self.assertEqual(points.admin(1, 2)["total_points"], 3)

    def test_slash_commands_have_no_duplicate_names(self) -> None:
        commands = bot.tree.get_commands()
        names = [command.name for command in commands]
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(len(names), 8)

    def test_ticket_select_includes_existing_and_submission_types(self) -> None:
        self.assertEqual(
            set(TICKET_TYPES),
            {
                "technical",
                "general",
                "complaint",
                "other",
                "admin_application",
                "partnership",
            },
        )
        self.assertEqual(
            {option.value for option in SupportSelect().options},
            set(TICKET_TYPES),
        )
        self.assertEqual(
            SUBMISSION_TYPES,
            {"admin_application", "partnership"},
        )

    def test_submission_modals_fit_discord_limit(self) -> None:
        self.assertEqual(len(AdminApplicationModal().children), 5)
        self.assertEqual(len(PartnershipModal().children), 5)

    def test_submission_decision_component_ids_are_unique(self) -> None:
        ids = [item.custom_id for item in SubmissionDecisionView().children]
        self.assertEqual(
            ids,
            [
                "leon_ticket:decision:accept",
                "leon_ticket:decision:reject",
            ],
        )

    def test_social_prefix_commands_share_one_command_and_current_links(self) -> None:
        command = bot.get_command("روابط")
        self.assertIsNotNone(command)
        self.assertIs(bot.get_command("مواقع"), command)
        self.assertIs(bot.get_command("social"), command)
        self.assertEqual(YOUTUBE_URL, "https://youtube.com/@ileonsar906?si=b6pSppr7AKRuWDNv")
        self.assertEqual(KICK_URL, "https://kick.com/ileonsar906")
        self.assertEqual(
            TIKTOK_URL,
            "https://www.tiktok.com/@ileonsar906?_r=1&_t=ZS-99OdoynFkgO",
        )

    def test_member_id_parser_accepts_ids_and_mentions(self) -> None:
        self.assertEqual(parse_discord_user_id("123456789"), 123456789)
        self.assertEqual(parse_discord_user_id("<@123456789>"), 123456789)
        self.assertEqual(parse_discord_user_id("<@!123456789>"), 123456789)
        self.assertIsNone(parse_discord_user_id("not-a-user"))

    def test_security_detects_embedded_links_and_invites(self) -> None:
        self.assertTrue(contains_prohibited_link("شاهد هنا https://example.com الآن"))
        self.assertTrue(contains_prohibited_link("دعوة discord.gg/example"))
        self.assertTrue(contains_prohibited_link("الموقع www.example.com/path"))
        self.assertTrue(contains_prohibited_link("زر site.sa/path"))
        self.assertTrue(contains_prohibited_link("رابط example.xyz"))
        self.assertTrue(contains_prohibited_link("مختصر bit.ly/test"))
        self.assertFalse(contains_prohibited_link("رسالة عادية بدون رابط"))

    def test_current_social_links_and_commands_are_not_security_violations(self) -> None:
        self.assertFalse(contains_prohibited_link(YOUTUBE_URL))
        self.assertFalse(contains_prohibited_link(KICK_URL))
        self.assertFalse(contains_prohibited_link(TIKTOK_URL))
        self.assertFalse(contains_prohibited_link("!روابط"))
        self.assertFalse(contains_prohibited_link("!مواقع"))
        self.assertFalse(contains_prohibited_link("!social"))
        self.assertTrue(
            contains_prohibited_link(f"{KICK_URL} https://example.com")
        )

    def test_security_detects_mass_mentions(self) -> None:
        self.assertTrue(contains_mass_mention("تنبيه @everyone"))
        self.assertTrue(contains_mass_mention("تنبيه @here"))
        self.assertTrue(contains_mass_mention("نص", mention_everyone=True))
        self.assertFalse(contains_mass_mention("مرحباً بالجميع"))


class TicketDatabaseTests(unittest.TestCase):
    def test_submission_decision_is_atomic_and_single_use(self) -> None:
        with TemporaryDirectory() as directory:
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            responses = {"الاسم": "عضو", "العمر": "20"}
            database.create_ticket(
                101,
                202,
                303,
                "admin_application",
                responses,
            )
            submission = database.get_submission(101)
            self.assertIsNotNone(submission)
            self.assertEqual(
                submission["submission_type"],
                "admin_application",
            )
            self.assertTrue(database.decide_submission(101, "accepted", 404))
            self.assertFalse(database.decide_submission(101, "rejected", 505))
            submission = database.get_submission(101)
            self.assertEqual(submission["decision"], "accepted")
            self.assertEqual(submission["decision_by"], 404)
            database.close()

    def test_ticket_settings_are_isolated_by_guild(self) -> None:
        with TemporaryDirectory() as directory, patch.dict(
            "os.environ",
            {},
            clear=True,
        ):
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            catalog = database.get_ticket_settings(CATALOG_GUILD_ID)
            self.assertIsNotNone(catalog)
            self.assertEqual(catalog.ticket_category_id, 0)
            self.assertEqual(
                catalog.ticket_log_channel_id,
                CATALOG_LOG_CHANNEL_ID,
            )

            first_guild = 111
            database.save_ticket_settings(first_guild, 222, 333, 444)
            database.save_ticket_settings(
                CATALOG_GUILD_ID,
                555,
                CATALOG_LOG_CHANNEL_ID,
                0,
            )
            first = database.get_ticket_settings(first_guild)
            catalog = database.get_ticket_settings(CATALOG_GUILD_ID)
            self.assertEqual(first.ticket_category_id, 222)
            self.assertEqual(first.ticket_log_channel_id, 333)
            self.assertEqual(catalog.ticket_category_id, 555)
            self.assertEqual(
                catalog.ticket_log_channel_id,
                CATALOG_LOG_CHANNEL_ID,
            )
            database.close()

    def test_security_settings_are_isolated_by_guild(self) -> None:
        with TemporaryDirectory() as directory:
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            first_guild = 111
            second_guild = 222
            database.save_security_settings(first_guild, 333)
            database.save_security_settings(second_guild, 444)

            first = database.get_security_settings(first_guild)
            second = database.get_security_settings(second_guild)
            unknown = database.get_security_settings(999)

            self.assertEqual(first.log_channel_id, 333)
            self.assertEqual(second.log_channel_id, 444)
            self.assertIsNone(unknown)
            database.close()

    def test_catalog_security_log_is_seeded_independently(self) -> None:
        with TemporaryDirectory() as directory:
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            settings = database.get_security_settings(CATALOG_GUILD_ID)
            self.assertIsNotNone(settings)
            self.assertEqual(
                settings.log_channel_id,
                1544577415668437024,
            )
            database.close()

    def test_reminders_are_one_time_and_failed_delivery_can_retry(self) -> None:
        with TemporaryDirectory() as directory:
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            database.create_ticket(101, 202, 303, "technical")

            record = database.get_ticket(101)
            self.assertEqual(record["member_reminded"], 0)
            self.assertEqual(record["staff_reminded"], 0)

            self.assertTrue(database.claim_reminder(101, "member_reminded"))
            self.assertFalse(database.claim_reminder(101, "member_reminded"))
            database.complete_reminder(101, "member_reminded")
            self.assertFalse(database.claim_reminder(101, "member_reminded"))

            self.assertTrue(database.claim_reminder(101, "staff_reminded"))
            database.release_reminder(101, "staff_reminded")
            self.assertTrue(database.claim_reminder(101, "staff_reminded"))
            database.close()


class PersistentViewTests(unittest.TestCase):
    def test_current_and_legacy_ticket_ids_are_supported(self) -> None:
        current_ids = {
            item.custom_id for item in TicketControlView().children
        }
        legacy_ids = {
            item.custom_id for item in TicketControlView(legacy=True).children
        }
        self.assertEqual(current_ids, set(LEGACY_COMPONENT_IDS))
        self.assertEqual(legacy_ids, set(LEGACY_COMPONENT_IDS.values()))

        current_select = TicketLauncher().children[0].custom_id
        legacy_select = TicketLauncher(legacy=True).children[0].custom_id
        self.assertEqual(current_select, "leon_ticket:type")
        self.assertEqual(legacy_select, LEGACY_SELECT_ID)

    def test_rating_component_ids_are_unique(self) -> None:
        ids = [item.custom_id for item in RatingView(123, 456).children]
        self.assertEqual(len(ids), 5)
        self.assertEqual(len(ids), len(set(ids)))

    def test_submitted_ratings_have_a_durable_points_outbox(self) -> None:
        with TemporaryDirectory() as directory:
            database = TicketDatabase(Path(directory) / "tickets.db")
            database.initialize()
            database.create_ticket(101, 202, 303, "technical")
            self.assertTrue(database.claim_ticket(101, 404))
            database.close_ticket(101, "done", "tester")
            rating = database.create_rating(101, 303, 404)
            self.assertTrue(database.submit_rating(rating["id"], 303, 5))
            pending = database.unprocessed_rating_points()
            self.assertEqual([row["id"] for row in pending], [rating["id"]])
            database.mark_rating_points_processed(rating["id"])
            self.assertEqual(database.unprocessed_rating_points(), [])
            database.close()

    def test_database_path_is_absolute(self) -> None:
        self.assertTrue(DATABASE_FILE.is_absolute())
        self.assertEqual(DATABASE_FILE.name, "leon_tickets.db")


class GameTests(unittest.TestCase):
    def test_prefix_game_state_and_cooldown_are_isolated_per_guild(self) -> None:
        now = [1000.0]
        registry = GameRegistry(clock=lambda: now[0])
        self.assertTrue(registry.start(1, "questions"))
        self.assertFalse(registry.start(1, "flag"))
        self.assertTrue(registry.start(2, "flag"))
        self.assertTrue(registry.toggle_player(1, 10))
        self.assertNotIn(10, registry.active[2].players)
        registry.finish(1)
        self.assertEqual(registry.cooldown_remaining(1), GAME_COOLDOWN)
        self.assertIn(2, registry.active)
        now[0] += GAME_COOLDOWN + 1
        self.assertTrue(registry.start(1, "map"))

    def test_player_limit_is_enforced_independently_per_guild(self) -> None:
        registry = GameRegistry(clock=lambda: 1000.0)
        self.assertTrue(registry.start(1, "questions"))
        self.assertTrue(registry.start(2, "questions"))
        for user_id in range(MAX_PLAYERS):
            self.assertEqual(
                registry.registration_action(1, user_id),
                "joined",
            )
        self.assertEqual(
            registry.registration_action(1, MAX_PLAYERS + 1),
            "full",
        )
        self.assertEqual(registry.registration_action(2, 999), "joined")
        self.assertEqual(len(registry.active[2].players), 1)

    def test_country_games_have_distinct_country_assets_and_choices(self) -> None:
        choices = country_choices("kw")
        self.assertEqual(len(choices), 4)
        self.assertEqual(len(set(choices)), 4)
        self.assertIn("الكويت", choices)
        self.assertIn("/kw", flag_url("kw"))
        self.assertIn("static-maps.yandex.ru", map_url("kw"))
        self.assertIn("pt=", map_url("kw"))
        self.assertEqual(len(COUNTRIES), 195)
        self.assertEqual(len(COUNTRY_CENTERS), 195)
        self.assertEqual(set(COUNTRIES), set(COUNTRY_CENTERS))

    def test_mafia_roles_and_win_conditions(self) -> None:
        roles = assign_mafia_roles(range(1, 9), random.Random(10))
        self.assertEqual(len(roles), 8)
        self.assertEqual(list(roles.values()).count("mafia"), 2)
        self.assertEqual(list(roles.values()).count("doctor"), 1)
        self.assertEqual(list(roles.values()).count("detective"), 1)
        mafia_ids = {
            player_id
            for player_id, role in roles.items()
            if role == "mafia"
        }
        civilians = set(roles) - mafia_ids
        self.assertEqual(mafia_winner(civilians, roles), "civilians")
        self.assertEqual(
            mafia_winner(mafia_ids | set(list(civilians)[:2]), roles),
            "mafia",
        )

    def test_security_rate_state_is_guild_local_when_owned_by_each_cog(self) -> None:
        from datetime import datetime, timezone

        state_one = GuildSecurityState()
        state_two = GuildSecurityState()
        now = datetime.now(timezone.utc)
        self.assertEqual(state_one.record_message(10, now), 1)
        self.assertEqual(state_one.record_message(10, now), 2)
        self.assertEqual(state_two.record_message(10, now), 1)

    def test_islamic_bank_has_five_hundred_questions(self) -> None:
        with TemporaryDirectory() as directory:
            database = GameDatabase(Path(directory) / "games.db")
            database.initialize()
            self.assertEqual(database.islamic_count(), 500)
            distinct = database.connection.execute(
                """
                SELECT COUNT(DISTINCT question)
                FROM game_questions WHERE kind = 'islamic'
                """
            ).fetchone()[0]
            self.assertEqual(distinct, 500)
            database.close()

    def test_guessing_bank_has_more_than_one_hundred_unique_items(self) -> None:
        items = [
            item
            for category_items in GUESS_CATEGORIES.values()
            for item in category_items
        ]
        self.assertGreater(len(items), 100)
        questions = guessing_questions(10)
        answers = {
            question["options"][question["correct_index"]]
            for question in questions
        }
        self.assertEqual(len(answers), 10)


if __name__ == "__main__":
    unittest.main()