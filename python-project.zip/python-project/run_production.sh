#!/usr/bin/env bash

# Keep the Discord bot alive on a Reserved VM. Replit starts this supervisor
# once; the supervisor restarts the bot after an unexpected process exit.
set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

restart_delay=5
max_restart_delay=60
child_pid=""
shutdown_requested=0

shutdown() {
    shutdown_requested=1
    if [[ -n "${child_pid}" ]]; then
        kill -TERM "${child_pid}" 2>/dev/null || true
    fi
}

trap shutdown TERM INT

while true; do
    echo "[SUPERVISOR] Starting LEON Discord Bot." >&2
    uv run --frozen python main.py &
    child_pid=$!

    set +e
    wait "${child_pid}"
    exit_status=$?
    set -e
    child_pid=""

    if (( shutdown_requested )); then
        echo "[SUPERVISOR] Shutdown requested; exiting cleanly." >&2
        exit 0
    fi

    echo "[SUPERVISOR] Bot exited with status ${exit_status}; restarting in ${restart_delay}s." >&2
    sleep "${restart_delay}"
    restart_delay=$((restart_delay * 2))
    if (( restart_delay > max_restart_delay )); then
        restart_delay=${max_restart_delay}
    fi
done